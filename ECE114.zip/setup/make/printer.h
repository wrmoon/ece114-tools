#include <string>
class Printer
{
    public:
        void printLine(int length);
        void printMsg(const std::string str);
};