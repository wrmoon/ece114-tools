# Profile Maker

Here are the instructions for taking the current profile and turning it into the bonafide profiles that the class can use

1. Export the current profile to this folder as ECE114-template.code-profile
1. Create profiles for MacOS, Windows and linux with `./make_template ECE114-template.code-profile`
1. Use the tool `make_zip.sh` in parent folder to create package
1. ??? Do something in github so that students can get the link to it. 